import arcade
import guiWindow
import multiplayerServer
import launchWindow
from PodSixNet.Connection import connection, ConnectionListener

class asteroidsClientWindow(ConnectionListener, arcade.View):
    def __init__(self, host, port):
        self.Connect((host, port))
        #add stuff here
        super().__init__()
        arcade.set_background_color(arcade.csscolor.INDIGO)

        # Lists are used for movemetn and collisions
        self.shipList = None
        self.shipSprite = None
        self.laserList = None
        self.astroidList = None
        self.phyEngine = None

        self.fireSound = arcade.load_sound(":resources:sounds/hurt5.wav")
        self.hitSound = arcade.load_sound(":resources:sounds/hit3.wav")

        self.lives = 3
        self.score = 0
        self.gameOver = False
        self.asteroidCount = 6
        self.threshold = 3


    def Loop(self):
        connection.Pump()
        self.Pump()

    def setUp(self):
        self.shipList = arcade.SrpiteList()

    def on_key_press(self, key, modifiers):
        ''' This is hacky but it works right now
            Adds the powerups to the ship speed
            because I can't access the shipSpeed
            var in the ship class '''
        adjShipSpeed = shipSpeed
        for x in self.shipSprite.powerupsTimeList:
            adjShipSpeed += x[1].increaseSpeed
        # Used to move the ship
        if key == arcade.key.W:
            self.shipSprite.speed = adjShipSpeed
            print(str(adjShipSpeed))
        elif key == arcade.key.S:
            self.shipSprite.speed = -adjShipSpeed
            print(str(adjShipSpeed))

        if key == arcade.key.SPACE:
            #Better but laser comes out side ways
            las = laser(":resources:images/space_shooter/laserBlue01.png", .5)

            las.change_x = -math.sin(math.radians(self.shipSprite.angle)) * laserSpeed
            las.change_y = math.cos(math.radians(self.shipSprite.angle)) * laserSpeed

            las.center_x = self.shipSprite.center_x
            las.center_y = self.shipSprite.center_y

            arcade.play_sound(self.fireSound)
            las.update()
            self.laserList.append(las)

        # Handles the rotation of the ship
        if key == arcade.key.A:
            self.shipSprite.change_angle = angleSpeed
        elif key == arcade.key.D:
            self.shipSprite.change_angle = -angleSpeed

        if key == arcade.key.ESCAPE:
            pauseGame = pause(self)
            self.window.show_view(pauseGame)

    def on_key_release(self, key, modifiers):
        # This should change to the the ship has momentum
        if key == arcade.key.W or key == arcade.key.S:
            self.shipSprite.speed = 0

        # Needed so that the ship doesn't just keep spinning
        if key == arcade.key.A or arcade.key.D:
            self.shipSprite.change_angle = 0
