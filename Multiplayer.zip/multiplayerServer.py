import arcade
import math
import random
import guiWindow
from time import sleep
from PodSixNet.Channel import Channel
from PodSixNet.Server import Server
from launchWindow import laser, powerup, asteroid, ship

_width = 960
_height = 540
_frame = "Asteroids"
_offScreenBuffer = 50
shipSpeed = 10
angleSpeed = 5
laserSpeed = 15

# https://arcade.academy/resources.html#resources-images-space-shooter
possibleAsteroidType = [":resources:images/space_shooter/meteorGrey_big1.png",
                        ":resources:images/space_shooter/meteorGrey_big2.png",
                        ":resources:images/space_shooter/meteorGrey_big3.png",
                        ":resources:images/space_shooter/meteorGrey_big4.png"]


class Player(Channel, ship):
    def __init__(self, name, imageSource, scale):
        super().__init__(imageSource, scale)
        self.speed = 0
        self.username = str(name)
        Channel.__init__(self)
        self.shipSprite = ship("Assets/bluecarrier.png", .125)
        self.shipSprite.center_x = _width / 2
        self.shipSprite.center_y = _height / 2

    def Close(self):
        self._server.DelPlayer(self)

class asteroidsServer(Server, arcade.View):
    channelClass = Player
    def __init__(self, host, port):
        arcade.View.__init__(self)
        arcade.set_background_color(arcade.csscolor.INDIGO)
        self.playerList = None
        self.laserList = None
        self.astroidList = None
        #self.phyEngine = None
        self.fireSound = arcade.load_sound(":resources:sounds/hurt5.wav")
        self.hitsound = arcade.load_sound(":resources:sounds/hit3.wav")
        self.asteroidCount = 6
        self.threshold = 3
        Server.__init__(self, localaddr=(host, port))

    def Connected(self, channel, addr):
        self.AddPlayer(channel)

    def AddPlayer(self, player):
        print("New Player" + str(player.addr))
        self.playerList.append(player)

    def DelPlayer(self, player):
        print("Deleting Player" + str(player.addr))
        self.playerList.remove(player)

    def addAsteroids(self, count):
        for i in range(0, count):
            asteroidSprite = asteroid(possibleAsteroidType[random.randrange(4)], .5)

            asteroidSprite.center_x = random.randrange(0, _height)
            asteroidSprite.center_y = random.randrange(0, _width)

            asteroidSprite.change_x = random.random() * 2
            asteroidSprite.change_y = random.random() * 2

            asteroidSprite.change_angle = math.radians(random.random())
            self.asteroidList.append(asteroidSprite)

    def setUp(self):
        self.playerList = arcade.SpriteList()
        # This is empty right now but when it's populated
        # the ship will crash into the asteroid Sprites
        self.asteroidList = arcade.SpriteList()

        self.powerupList = arcade.SpriteList()
        for x in range(4):
            powerupSprite = powerup("Assets/powerup.png", 1)
            powerupSprite.center_x = _width / (x + 1)
            powerupSprite.center_y = _width / (x + 1)
            self.powerupList.append(powerupSprite)

        self.laserList = arcade.SpriteList()

        self.addAsteroids(self.asteroidCount)
        #self.playerList.append(self.shipSprite)

        # The second param makes it so that the first element pass through it
        # so for this we need to asteroids to overlap the ship so we have a
        # collision
        #self.phyEngine = arcade.PhysicsEngineSimple(self.shipSprite, arcade.SpriteList())

    def on_update(self, delta_time):
        self.playerList.update()
        self.laserList.update()
        self.asteroidList.update()
        #self.phyEngine.update()
        self.powerupList.update()

        if len(self.asteroidList) <= self.threshold:
            # Don't know how we should make the game increasingly
            # more difficult, but this does just that
            self.threshold += 1
            self.asteroidCount += self.asteroidCount // 2
            self.addAsteroids(self.asteroidCount)
            self.SendToAll(self)
            self.Pump()
        ''''' Get the collisions between ship and powerups '''
        #getPow = arcade.check_for_collision_with_list(self.shipSprite, self.powerupList)
        #
        ''' For each collision add the powerup to
            the ship and remove it from the game '''
        '''for hitPow in getPow:
            self.playerList[0].getPowerup(hitPow, 5)
            hitPow.remove_from_sprite_lists()

        for rock in self.asteroidList:
            rockHits = arcade.check_for_collision_with_list(self.shipSprite, self.asteroidList)

            if len(rockHits) > 0:
                if self.lives > 0:
                    rockHits[0].remove_from_sprite_lists()
                    self.lives -= 1

        for laser in self.laserList:
            laserHit = arcade.check_for_collision_with_list(laser, self.asteroidList)

            # Delets that laser the asteroid that it hit
            for hit in laserHit:
                arcade.play_sound(self.hitSound)
                self.score += 100
                hit.remove_from_sprite_lists()
                laser.remove_from_sprite_lists()

            # This block will remove a laser once it has moved of
            # screen keeping our memory usage under control
            # print(len(self.laserList))
            if laser.right < 0:
                laser.remove_from_sprite_lists()
            if laser.left > _width:
                laser.remove_from_sprite_lists()
            if laser.top > _height:
                laser.remove_from_sprite_lists()
            if laser.bottom < 0:
                laser.remove_from_sprite_lists()
            # print(len(self.laserList))
            '''

    def on_draw(self):
        arcade.start_render()
        self.playerList.draw()
        self.laserList.draw()
        self.asteroidList.draw()
        self.powerupList.draw()

if __name__ == "__main__":
    window = arcade.Window(_width, _height, _frame)
    idk = asteroidsServer("localhost", 2000)
    idk.setUp()
    window.show_view(idk)
    arcade.run()
